.data 76
vector: .dw .ascii16 'EDUARDO GUERRERO.'; char16_t vector[]={0x0045, 0x0044, 0x0055, 0x0041, 0x0052, 0x0044, 0x004f, 0x0020, 0x0047, 0x0055, 0x0045, 0x0052, 0x0052, 0x0045, 0x0052, 0x004f, 0x002e};
punto: .ascii16 '.'         ; char16_t punto=0x002E;
letra: .rw 1                ; char letra=0x0000;
cero: .dw 0                 ; int cero=0;
const: .dw 80               ; int const=80; 
minuscula: .dw 20           ; int minuscula=20;
espacio: .ascii16 ' '       ; char espacio=0x0020; 
.data 127                   ; @ memoria para imprimir en tty
tty_out: .rw 1              ; char16_t tty_out=0x0001;
.code
mov cero, tty_out           ; borrar_pantalla();
mov vector, letra           ; letra = vector[0];
add minuscula, letra        ; letra += minuscula; 
WHILE: cmp punto, letra     ; while (letra != punto) {
beq halt                    ;
mov letra, tty_out          ; imprimir(letra);
add const, INST             ;
INST: mov vector, letra     ; letra = vector[i];
cmp espacio, letra          ; if (espacio == letra) {
beq while                   ; } }
cmp punto, letra            ; if (letra == punto) {
beq while                   ; } }
add minuscula, letra        ; letra += minuscula; 
cmp cero, cero              ; 
beq while                   ; }
HALT: cmp cero, cero        ; halt();
beq HALT                    ;
.end
