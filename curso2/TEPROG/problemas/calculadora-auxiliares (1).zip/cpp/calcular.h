#pragma once

#include <string>
#include <cmath>

inline bool esDigito(char c) {
	return ((c>='0') && (c<='9'));
}

double calcular(const std::string& expresion);

inline double primerValor(const std::string& expresion, std::size_t& next_pos) {
	std::size_t i = 0;
	while (expresion[i]==' ') ++i;
	if (esDigito(expresion[i]) || (expresion[i]=='-')) { //Es un numero, nos lo recorremos entero
		int start=i;
		if (expresion[i]=='-') ++i;
		while ((i<expresion.size()) && esDigito(expresion[i])) ++i;
		//Si es un punto seguimos porque tiene decimales
		if ((i<expresion.size()) && (expresion[i]=='.')) { 
			++i;
			while ((i<expresion.size()) && esDigito(expresion[i])) ++i;
		}
		next_pos = i; 
		return stod(expresion.substr(start,i - start));
	} else if (expresion[i]=='(') { //Es algo entre parentesis, me lo trago entero hasta el parentesis de cierre y lo evaluo recursivamente
		int anidamiento = 1; int start = (i+1); ++i;
		while ((anidamiento>0) && (i<expresion.size())) {
			if (expresion[i]=='(') ++anidamiento;
			else if (expresion[i]==')') --anidamiento;
			++i;
		}
		next_pos=i;
		return calcular(expresion.substr(start, i - start - 1));	
	}
}

inline double calcular(const std::string& expresion) {
	std::size_t i = 0;
	double acumulado = primerValor(expresion,i);
	while ((i<expresion.size()) && (expresion[i]==' ')) ++i;
	while (i<expresion.size()) {
		//Buscamos el operador
		char op = expresion[i]; //El operador aparece ahora
		std::size_t local_i;
		double siguiente = primerValor(expresion.substr(i+1),local_i);
		i = (local_i + i + 1);
		
		switch (op) {
			case '+': acumulado += siguiente; break;
			case '-': acumulado -= siguiente; break;
			case '*': acumulado *= siguiente; break;
			case '/': acumulado /= siguiente; break;
			case '^': acumulado = std::pow(acumulado, siguiente); break;
		}
	}
	return acumulado;
}

