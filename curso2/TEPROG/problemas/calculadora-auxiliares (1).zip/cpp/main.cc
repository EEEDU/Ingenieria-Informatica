#include <iostream>
#include "calcular.h"

int main(int argc, char** argv) {
	std::cout<<calcular(std::string(argv[1]))<<std::endl;
}
