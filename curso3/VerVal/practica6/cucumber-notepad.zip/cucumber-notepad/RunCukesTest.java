package es.unizar.eina.notepad.test;

import io.cucumber.junit.CucumberOptions;

@CucumberOptions(
        features = {"features"}
)
public class RunCukesTest {
}